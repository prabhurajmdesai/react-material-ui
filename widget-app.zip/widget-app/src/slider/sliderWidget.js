import * as React from "react";
import { styled, useTheme } from "@mui/material/styles";
import Slider from "@mui/material/Slider";
import UsingColorObject from "../../src/pallete/color";

const Widget = styled("div")(({ theme }) => ({
  padding: 16,
  borderRadius: 16,
  width: 343,
  maxWidth: "100%",
  margin: "auto",
  position: "relative",
  zIndex: 3,
  background:
    "radial-gradient(at center center, rgb(247, 237, 225) 0%, rgba(247, 237, 225, 0) 70%)",
  backdropFilter: "blur(40px)",
}));

export default function SliderWidget() {
  const theme = useTheme();

  const [bottomPercentage, SetBottom] = React.useState();
  const [Display, setDisplay] = React.useState();
  const [BorderRadius, setBorderRadius] = React.useState();
  function valuetext(value) {
    console.log(value);
    let bottomVal = value;
    if (value > 90) {
      setBorderRadius("20px");
    } else {
      setBorderRadius("0px 0px 20px 20px");
    }
    if (value >= 4) {
      bottomVal = value - 4;
      setDisplay("block");
    } else {
      setDisplay("none");
    }
    console.log(bottomVal);
    SetBottom(bottomVal.toString() + "% !important");
    return `${value}°C`;
  }
  return (
    <Widget>
      <Slider
        orientation="vertical"
        aria-label="Volume"
        defaultValue={30}
        getAriaValueText={valuetext}
        sx={{
          color: theme.palette.mode === "dark" ? "#fff" : "black",
          height: 300,
          width: 80,
          borderRadius: "20px",
          "& .MuiSlider-track": {
            border: "none",
            display: Display,
            borderRadius: BorderRadius,
          },
          "& .MuiSlider-thumb": {
            width: 40,
            height: "6px",
            bottom: bottomPercentage,
            borderRadius: 2,
            position: "absolute",
            "&::before": {
              boxShadow: "0 4px 8px rgba(0,0,0,0.4)",
              backgroundColor: "white",
            },
            "&:hover, &.Mui-focusVisible, &.Mui-active": {
              boxShadow: "none",
            },
          },
        }}
      />
      <br />
      <div>
        <UsingColorObject />
      </div>
    </Widget>
  );
}
