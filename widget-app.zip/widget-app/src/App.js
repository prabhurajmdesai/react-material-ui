// import "./App.css";
import SliderWidget from "../src/slider/sliderWidget";

function App() {
  return (
    <div>
      <br />
      <SliderWidget />
    </div>
  );
}

export default App;
